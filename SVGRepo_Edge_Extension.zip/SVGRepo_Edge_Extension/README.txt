SVGRepo Collection Downloader for Microsoft Edge
================================================

Purpose
-------
This extension does NOT bypass SVGRepo/Vercel browser verification.
Open SVGRepo normally in Microsoft Edge and complete any browser verification yourself.
Once the collection page is visible, the extension scans that already-rendered page for SVG asset URLs and asks Edge to download them.

Install in Edge
---------------
1. Extract SVGRepo_Edge_Extension.zip.
2. Open Microsoft Edge.
3. Enter edge://extensions in the address bar.
4. Turn on Developer mode.
5. Click Load unpacked.
6. Select the extracted SVGRepo_Edge_Extension folder.

Use
---
1. Open the SVGRepo collection normally in Edge.
2. If a browser verification page appears, complete it normally.
3. When the collection is actually visible, click the Extensions button and open SVGRepo Collection Downloader.
4. Click "1. Scan current collection".
5. Confirm the number of files found.
6. Click "2. Download SVGs".

Downloads
---------
By default, Edge saves files under:
Downloads\SVGRepo\<collection-name>\

The extension cannot silently force downloads to an arbitrary Windows Desktop folder. If you enable "Ask where to save each file", Edge will prompt for each file.

Troubleshooting
---------------
- If SVGRepo itself still shows Code 21 in your normal non-automated Edge window, the extension cannot fix that checkpoint. Resolve normal browser access first.
- If the collection page is visible but Scan finds 0 files, SVGRepo has probably changed its rendered HTML structure.
- If downloads return 429, stop retrying repeatedly and use SVGRepo's normal browser download workflow after the rate limit clears.
